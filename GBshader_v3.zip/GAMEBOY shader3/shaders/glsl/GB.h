#ifndef GB_H
#define GB_H
vec3 gameboy(vec3 col){

	float step = 4.;
	vec3 panel_col = vec3(0.6,0.8,0.2);

	float gray = dot(col, vec3(0.298912, 0.586611, 0.114478));
	return panel_col/step*ceil(gray*step);
}
#endif
